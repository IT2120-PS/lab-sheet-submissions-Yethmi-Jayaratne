getwd()
setwd("C:\\Users\\it24100284\\Desktop\\IT24100284")
getwd()
#1
branch_data <- read.table("Exercise.txt", header = TRUE, sep = " ")
fix(branch_data)
attach(branch_data)

#2
str(branch_data)

#3
boxplot(branch_data$sales, main = "Boxplot for Sales", ylab = "Sales")

#4
summary(branch_data$advertising)
IQR(branch_data$advertising)

#5
#5
find_outliers <- function(z) {
  Q1 <- quantile(z, 0.25)
  Q3 <- quantile(z, 0.75)
  IQR <- Q3 - Q1
  
  ub <- Q3 + 1.5 * IQR
  lb <- Q1 - 1.5 * IQR
  
  print (paste ("Upper Bound = ", ub))
  print (paste ("Lower Bound = ", lb))
  print (paste("outliers <- z[z < lb | z > ub]"))
  
}

get.outliers(X3)
